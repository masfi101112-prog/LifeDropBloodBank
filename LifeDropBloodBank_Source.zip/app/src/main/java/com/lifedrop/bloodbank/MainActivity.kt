package com.lifedrop.bloodbank

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val DONORS = "donors"
private val bloodGroups = listOf("সব", "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { LifeDropApp() } }
    }
}

data class Donor(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val bloodGroup: String = "",
    val district: String = "",
    val upazila: String = "",
    val address: String = "",
    val lastDonationDate: String = "",
    val nextEligibleDate: String = "",
    val active: Boolean = true
)

private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

@Composable
fun LifeDropApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var donors by remember { mutableStateOf(listOf<Donor>()) }
    var selectedGroup by remember { mutableStateOf("সব") }
    var districtQuery by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var donorName by remember { mutableStateOf("") }
    var donorPhone by remember { mutableStateOf("") }
    var donorGroup by remember { mutableStateOf("A+") }
    var donorDistrict by remember { mutableStateOf("") }
    var donorUpazila by remember { mutableStateOf("") }
    var donorAddress by remember { mutableStateOf("") }
    var lastDate by remember { mutableStateOf("") }
    var registration by remember { mutableStateOf<ListenerRegistration?>(null) }

    // IMPORTANT: Put the admin UID(s) here AND in firestore.rules.
    // Never treat a hidden button as security; Firestore rules enforce access.
    val adminUids = remember { setOf("REPLACE_WITH_YOUR_ADMIN_FIREBASE_UID") }
    val isAdmin = user?.uid != null && user!!.uid in adminUids

    DisposableEffect(user?.uid) {
        registration?.remove()
        registration = null
        if (user != null) {
            registration = db.collection(DONORS).addSnapshotListener { snap, error ->
                if (error != null) {
                    message = "তথ্য লোড হয়নি: ${error.localizedMessage ?: "সমস্যা"}"
                } else {
                    donors = snap?.documents?.mapNotNull { d ->
                        d.toObject(Donor::class.java)?.copy(id = d.id)
                    }?.filter { it.active } ?: emptyList()
                }
            }
        }
        onDispose { registration?.remove() }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("🩸 LifeDrop Blood Bank", style = MaterialTheme.typography.headlineSmall)
            Text("রক্তদাতা খুঁজুন • রক্তদানের রেকর্ড রাখুন")
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)

            if (user == null) {
                OutlinedTextField(email, { email = it }, label = { Text("ইমেইল") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(password, { password = it }, label = { Text("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)") }, modifier = Modifier.fillMaxWidth())
                Button(
                    onClick = {
                        if (email.isBlank() || password.length < 6) {
                            message = "সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।"
                        } else {
                            auth.signInWithEmailAndPassword(email.trim(), password)
                                .addOnSuccessListener { user = auth.currentUser; message = "লগইন হয়েছে।" }
                                .addOnFailureListener {
                                    message = "লগইন হয়নি। নতুন হলে 'অ্যাকাউন্ট তৈরি' ব্যবহার করুন।"
                                }
                        }
                    }, modifier = Modifier.fillMaxWidth()
                ) { Text("লগইন") }
                OutlinedButton(
                    onClick = {
                        if (email.isBlank() || password.length < 6) {
                            message = "সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।"
                        } else {
                            auth.createUserWithEmailAndPassword(email.trim(), password)
                                .addOnSuccessListener { user = auth.currentUser; message = "অ্যাকাউন্ট তৈরি হয়েছে।" }
                                .addOnFailureListener { message = "অ্যাকাউন্ট তৈরি হয়নি: ${it.localizedMessage}" }
                        }
                    }, modifier = Modifier.fillMaxWidth()
                ) { Text("নতুন অ্যাকাউন্ট তৈরি") }
                Text("দাতাদের ব্যক্তিগত তথ্য কেবল অনুমতি নিয়ে যোগ করুন।")
            } else {
                Text("লগইন: ${user?.email ?: "ব্যবহারকারী"}")
                OutlinedButton(onClick = {
                    auth.signOut(); user = null; donors = emptyList(); message = "লগআউট হয়েছে।"
                }) { Text("লগআউট") }

                Text("রক্তদাতা খুঁজুন", style = MaterialTheme.typography.titleLarge)
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }) { Text("রক্তের গ্রুপ: $selectedGroup") }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        bloodGroups.forEach { group ->
                            DropdownMenuItem(text = { Text(group) }, onClick = {
                                selectedGroup = group; expanded = false
                            })
                        }
                    }
                }
                OutlinedTextField(
                    districtQuery, { districtQuery = it },
                    label = { Text("জেলা লিখুন (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth()
                )

                val filtered = donors.filter {
                    (selectedGroup == "সব" || it.bloodGroup == selectedGroup) &&
                    it.district.contains(districtQuery.trim(), ignoreCase = true)
                }
                Text("মোট ফলাফল: ${filtered.size}")
                filtered.forEach { donor ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${donor.name} • ${donor.bloodGroup}", style = MaterialTheme.typography.titleMedium)
                            Text("${donor.district}, ${donor.upazila}")
                            if (donor.address.isNotBlank()) Text("ঠিকানা: ${donor.address}")
                            Text("শেষ রক্তদান: ${donor.lastDonationDate.ifBlank { "রেকর্ড নেই" }}")
                            Text("পরবর্তী সম্ভাব্য তারিখ: ${donor.nextEligibleDate.ifBlank { "নির্ধারিত নয়" }}")
                            Text("ফোন: ${donor.phone}")
                            if (isAdmin) {
                                OutlinedButton(onClick = {
                                    val donationDate = today()
                                    db.collection(DONORS).document(donor.id)
                                        .collection("donationHistory").add(
                                            mapOf("donationDate" to donationDate, "recordedBy" to user!!.uid)
                                        ).addOnSuccessListener {
                                            // 90 days is only a reminder estimate, not medical clearance.
                                            val next = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(
                                                java.util.Calendar.getInstance().apply { time = Date(); add(java.util.Calendar.DAY_OF_YEAR, 90) }.time
                                            )
                                            db.collection(DONORS).document(donor.id).update(
                                                mapOf("lastDonationDate" to donationDate, "nextEligibleDate" to next)
                                            ).addOnSuccessListener { message = "রক্তদানের রেকর্ড যোগ হয়েছে।" }
                                        }.addOnFailureListener { message = "রেকর্ড যোগ হয়নি: ${it.localizedMessage}" }
                                }) { Text("আজ রক্ত দিয়েছেন — রেকর্ড করুন") }
                                OutlinedButton(onClick = {
                                    db.collection(DONORS).document(donor.id).update("active", false)
                                        .addOnSuccessListener { message = "দাতা তালিকা থেকে নিষ্ক্রিয় করা হয়েছে।" }
                                        .addOnFailureListener { message = "পরিবর্তন করা যায়নি: ${it.localizedMessage}" }
                                }) { Text("তালিকা থেকে সরান") }
                            }
                        }
                    }
                }
                if (filtered.isEmpty()) Text("কোনো দাতা পাওয়া যায়নি। পরে আবার খুঁজুন।")

                if (isAdmin) {
                    Divider()
                    Text("অ্যাডমিন: নতুন দাতা যোগ করুন", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(donorName, { donorName = it }, label = { Text("নাম") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(donorPhone, { donorPhone = it }, label = { Text("ফোন নম্বর (অনুমতি নিয়ে)") }, modifier = Modifier.fillMaxWidth())
                    var groupExpanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { groupExpanded = true }) { Text("রক্তের গ্রুপ: $donorGroup") }
                        DropdownMenu(expanded = groupExpanded, onDismissRequest = { groupExpanded = false }) {
                            bloodGroups.drop(1).forEach { g ->
                                DropdownMenuItem(text = { Text(g) }, onClick = { donorGroup = g; groupExpanded = false })
                            }
                        }
                    }
                    OutlinedTextField(donorDistrict, { donorDistrict = it }, label = { Text("জেলা") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(donorUpazila, { donorUpazila = it }, label = { Text("উপজেলা") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(donorAddress, { donorAddress = it }, label = { Text("ঠিকানা (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(lastDate, { lastDate = it }, label = { Text("শেষ রক্তদানের তারিখ YYYY-MM-DD (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        if (donorName.isBlank() || donorPhone.isBlank() || donorDistrict.isBlank() || donorUpazila.isBlank()) {
                            message = "নাম, ফোন, জেলা ও উপজেলা পূরণ করুন।"
                        } else {
                            val next = if (lastDate.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                                runCatching {
                                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                                    val date = sdf.parse(lastDate)!!
                                    java.util.Calendar.getInstance().apply { time = date; add(java.util.Calendar.DAY_OF_YEAR, 90) }.time.let { sdf.format(it) }
                                }.getOrDefault("")
                            } else ""
                            val data = hashMapOf(
                                "name" to donorName.trim(), "phone" to donorPhone.trim(),
                                "bloodGroup" to donorGroup, "district" to donorDistrict.trim(),
                                "upazila" to donorUpazila.trim(), "address" to donorAddress.trim(),
                                "lastDonationDate" to lastDate.trim(), "nextEligibleDate" to next,
                                "active" to true
                            )
                            db.collection(DONORS).add(data)
                                .addOnSuccessListener {
                                    message = "দাতা যোগ হয়েছে।"; donorName = ""; donorPhone = ""
                                    donorDistrict = ""; donorUpazila = ""; donorAddress = ""; lastDate = ""
                                }.addOnFailureListener { message = "দাতা যোগ হয়নি: ${it.localizedMessage}" }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("দাতা সংরক্ষণ করুন") }
                } else {
                    Text("অ্যাডমিন সুবিধা দেখতে অ্যাডমিনের অনুমোদিত অ্যাকাউন্ট দরকার।")
                }
                Text(
                    "স্বাস্থ্য-সতর্কতা: ৯০ দিন কেবল একটি আনুমানিক অনুস্মারক। রক্তদানের উপযুক্ততা রক্তকেন্দ্র/চিকিৎসক নিশ্চিত করবেন।",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
