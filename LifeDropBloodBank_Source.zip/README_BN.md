# LifeDrop Blood Bank — ফোন থেকে APK তৈরির নির্দেশনা

## এই সংস্করণে কী আছে
- ইমেইল/পাসওয়ার্ড দিয়ে অ্যাকাউন্ট তৈরি ও লগইন
- রক্তের গ্রুপ ও জেলা দিয়ে দাতা খোঁজা
- অ্যাডমিন দাতা যোগ করতে পারেন
- অ্যাডমিন রক্তদানের ইতিহাসে তারিখ যোগ করতে পারেন
- Firestore থেকে লাইভ ডেটা সিঙ্ক

এটি একটি প্রাথমিক MVP। SMS OTP, ছবি, পুশ নোটিফিকেশন, রিপোর্টিং, উন্নত প্রশাসনিক ভূমিকা, এবং Play Store release signing এখনও যোগ করা হয়নি।

## ১. Firebase তৈরি
1. https://console.firebase.google.com খুলে Google অ্যাকাউন্টে লগইন করুন।
2. Create project চাপুন; নাম দিন `LifeDrop Blood Bank`.
3. Android app যোগ করুন। Package name অবশ্যই `com.lifedrop.bloodbank`.
4. `google-services.json` ডাউনলোড করে এই প্রকল্পের `app/` ফোল্ডারে রাখুন।
5. Authentication > Sign-in method > Email/Password চালু করুন।
6. Authentication > Users থেকে নিজের অ্যাকাউন্ট তৈরি করুন (অ্যাপ চালিয়ে Sign up করেও করা যাবে)।
7. Firestore Database তৈরি করুন।
8. Firestore Rules অংশে `firestore.rules` ফাইলের নিয়ম বসান; placeholder UID প্রতিস্থাপন করুন।

## ২. অ্যাডমিন UID সেট করা
1. অ্যাপ চালিয়ে নিজের ইমেইল দিয়ে অ্যাকাউন্ট তৈরি করুন।
2. Firebase Console > Authentication > Users থেকে ওই ব্যবহারকারীর UID কপি করুন।
3. `app/src/main/java/com/lifedrop/bloodbank/MainActivity.kt` ফাইলে `REPLACE_WITH_YOUR_ADMIN_FIREBASE_UID` বদলে নিজের UID দিন।
4. `firestore.rules` ফাইলেও একই UID বসান।
5. আপডেট করা rules Publish করুন।
6. অ্যাপ আবার build করুন।

**গুরুত্বপূর্ণ:** UID-টি গোপন পাসওয়ার্ড নয়, কিন্তু শুধু নিজের অ্যাডমিন UID-কে অনুমতি দিন। Firestore rules ছাড়া অ্যাপ চালু করবেন না। Test mode-এ ডেটাবেস রেখে দেবেন না।

## ৩. ফোন দিয়ে APK তৈরি
এই প্রকল্পে GitHub Actions workflow দেওয়া আছে:
1. GitHub-এ নতুন private repository তৈরি করুন।
2. ZIP ফাইল extract করে সব project file repository-তে upload করুন।
3. Firebase থেকে পাওয়া `google-services.json` `app/` ফোল্ডারে যোগ করুন। এটি API secret নয়, তবে private repository ব্যবহার করাই ভালো।
4. GitHub repository-র Actions tab খুলুন।
5. `Build LifeDrop APK` workflow বেছে `Run workflow` চাপুন।
6. Build সফল হলে workflow run-এর নিচে `LifeDrop-debug-apk` artifact ডাউনলোড করুন।
7. ZIP artifact extract করে `app-debug.apk` ফোনে খুলুন এবং Android-এর অনুমতি দিয়ে ইনস্টল করুন।

GitHub Actions ব্যবহার করতে GitHub account এবং ইন্টারনেট লাগবে। এই ZIP নিজে APK নয়; এটি APK তৈরির source project।

## ৪. স্বাস্থ্য ও গোপনীয়তা
- দাতার নাম/ফোন/ঠিকানা যোগ করার আগে স্পষ্ট অনুমতি নিন।
- এই MVP-তে লগইন করা প্রত্যেক ব্যবহারকারী দাতাদের রেকর্ড পড়তে পারে; বাস্তবে প্রকাশের আগে ফোন নম্বর/ঠিকানা সীমিত দেখানোর ব্যবস্থা করুন।
- ৯০ দিনের হিসাবটি কেবল আনুমানিক অনুস্মারক, চিকিৎসাগত অনুমতি নয়। রক্তকেন্দ্র/চিকিৎসকের সিদ্ধান্তই চূড়ান্ত।
- বাস্তব ব্যবহারের আগে donor verification, abuse reporting, data deletion, privacy policy, backup ও security review যোগ করুন।
